function table(array) {
    document.write('<table>');
    let incr = 0;
    
    for (let r = 0; r < 3; r++) {
        document.write('<tr>');
            document.write('<td>' + array[incr] + '</td>');
            incr += 1;

            document.write('<td>' + array[incr] + '</td>');
            incr += 1;

            document.write('<td>' + array[incr] + '</td>');
            incr += 1;

            document.write('<td>' + array[incr] + '</td>');
            incr += 1;

        document.write('</td>');
    }
}

function randomize(array) {
    let currentIndex = array.length,  randomIndex;

    while (currentIndex != 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;

        [array[currentIndex], array[randomIndex]] = 
        [array[randomIndex], array[currentIndex]];
    }

    return array;
}  

const array = ['ELEPHANT', 'ELEPHANT', 'GIRAFFE', 'GIRAFFE', 'LION', 'LION', 'MONKEY', 'MONKEY', 'HIPPO', 'HIPPO', 'ZEBRA', 'ZEBRA'];
let randomArray = randomize(array);

table(randomArray);